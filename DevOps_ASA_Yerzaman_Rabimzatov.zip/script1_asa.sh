#!/bin/bash

output_file="/tmp/first_bash_output"
current_date=$(date)
current_dir=$(pwd)

echo "$current_date" > "$output_file"
echo "$current_dir" >> "$output_file"

echo "Output saved to $output_file"
