#!/bin/bash

# Check if a path is provided as an argument
if [ -z "$1" ]; then
  echo "Usage: $0 <path>"
  exit 1
fi

# Store the provided path
input_path="$1"

# Check if the input is a valid directory
if [ ! -d "$input_path" ]; then
  echo "Error: $input_path is not a valid directory."
  exit 2
fi

# Count the number of directories and files inside the path
num_directories=$(find "$input_path" -mindepth 1 -type d | wc -l)
num_files=$(find "$input_path" -mindepth 1 -type f | wc -l)

# Display the results
echo "Directories: $num_directories Files: $num_files"
